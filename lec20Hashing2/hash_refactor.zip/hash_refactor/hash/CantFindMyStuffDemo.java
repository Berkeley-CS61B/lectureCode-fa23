package hw3.hash_refactor.hash;
import java.util.HashSet;

public class CantFindMyStuffDemo {

    public static void main(String[] args) {
        int N = 20;
        HashSet<ColoredNumber> hs = new HashSet<>();
        for (int i = 0; i < N; i += 1) {
            hs.add(new ColoredNumber(12));
        }
        ColoredNumber twelve = new ColoredNumber(12);
        System.out.println(hs.size());
        System.out.println(hs.contains(twelve));
    }
}
