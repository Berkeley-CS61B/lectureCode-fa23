package hw3.hash_refactor.hash;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdRandom;
import org.apache.commons.lang3.ArrayUtils;

import java.util.*;

public class HashTableVisualizer {
    List<ColoredNumber> cns = new ArrayList<>();
    boolean randomNumbers = false;

    double scale = 1.0;
    int N = 2000; // 0, 1, 2, ... 19
    int M = 16;
    double resizeFactor = 0.75;
    int pauseTime = 200;
    int verboseratio = 1;


    public void runSimulation() {

        StdRandom.setSeed(5);
        HashTableDrawingUtility.setScale(scale);
        cns = new ArrayList<>();
        if (!randomNumbers) {
            for (int i = 0; i < N; i += 1) {
                addAndVisualize(i, i%verboseratio == 0);
            }
        } else {
            for (int i = 0; i < N; i += 1) {
                addAndVisualize(StdRandom.uniform(N * 10), i%verboseratio == 0);
            }
        }
    }

    public static void main(String[] args) {
        HashTableVisualizer htv = new HashTableVisualizer();
        htv.runSimulation();
    }

    private void addAndVisualize(int n, boolean verbose) {
        ColoredNumber cn = new ColoredNumber(n);
        cns.add(cn);
        if(verbose) System.out.printf("Adding item %s with number %d and hashCode %d. ", cn, n, cn.hashCode());
        if(cns.size() / (double) M > resizeFactor) {
            M*=2;
            scale /=1.4;
            pauseTime/=2;
            HashTableDrawingUtility.resetScale(scale);
            if(verbose) System.out.printf("Resize occurred to %d buckets. ", M);
        }
        visualize(cns, M, scale, verbose);
        if(verbose) System.out.print("\n");
        StdDraw.pause(pauseTime);
    }

    public void visualize(List<ColoredNumber> cns, int M, double scale, boolean verbose) {
        HashTableDrawingUtility.drawLabels(M);

        List<ColoredNumber>[] buckets = preprocess(cns);
        int maxbucketsize = 0;
        for (int i = 0; i < buckets.length; i++) {
            if(buckets[i]!=null) {
                maxbucketsize = Math.max(maxbucketsize, buckets[i].size());
                for (int j = 0; j < buckets[i].size(); j++) {
                    double x = HashTableDrawingUtility.xCoord(j);
                    double y = HashTableDrawingUtility.yCoord(i, M);
                    buckets[i].get(j).draw(x, y, scale);
                }
            }
        }
        if(verbose) System.out.printf("Current Hash Table has %d elements in the largest bin.", maxbucketsize);
        StdDraw.show();
    }

    /** Simulate the deduplicating effect of a hash set */
    private List<ColoredNumber>[] preprocess(List<ColoredNumber> oomages) {
        List<ColoredNumber>[] newList = new List[M];
        for (ColoredNumber element : oomages) {
            int bucket = Math.floorMod(element.hashCode(), M);
            if(newList[bucket] == null) newList[bucket] = new ArrayList<>();
            newList[bucket].remove(element);
            newList[bucket].add(element);
        }
        return newList;
    }


} 
