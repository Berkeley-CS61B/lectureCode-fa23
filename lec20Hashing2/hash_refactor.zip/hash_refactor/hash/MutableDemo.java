package hw3.hash_refactor.hash;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class MutableDemo {
    public static void main(String[] args) {
        List<Integer> items = new ArrayList<>();
        items.add(0);
        items.add(1);
        System.out.println(items.hashCode());

        HashSet<List<Integer>> hs = new HashSet<>();
        hs.add(items);
        hs.add(List.of(2, 3));
        items.add(7);
        System.out.println(items.hashCode());
        System.out.println(hs.contains(items));
    }
}
