import java.util.List;

public class Closest {
    public static double distance(Point start, Point dest) {
        return Math.sqrt((start.x-dest.x)^2 + (start.y - dest.y)^2);
    }
    public static double closest(Point[] points) {
        if(points.length<2) {
            return 0.0;
        }
        double bestdistance = Double.POSITIVE_INFINITY;
        for (int i = 0; i < points.length; i++) {
            for (int j = 0; j < points.length; j++) {
                double newdistance = distance(points[i], points[j]);
                System.out.printf("Distance between Point %s and Point %s is %f%n",points[i], points[j], newdistance);
                if (bestdistance < newdistance) {
                    bestdistance = newdistance;
                }
            }
        }
        return bestdistance;
    }
}