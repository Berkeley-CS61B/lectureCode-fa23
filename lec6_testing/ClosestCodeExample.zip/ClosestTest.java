import org.junit.Test;

import static com.google.common.truth.Truth.assertThat;

public class ClosestTest {
    @Test
    public void testClosest() {
        Point[] input = {new Point(0,0),
                new Point(3,4),
                new Point(10,10),
                new Point(20,20),
        };
        double output = Closest.closest(input);
        assertThat(output).isEqualTo(5.0);
    }
}
